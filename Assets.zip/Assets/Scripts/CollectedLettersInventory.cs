using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CollectedLettersInventory : MonoBehaviour
{
    
    public static CollectedLettersInventory Instance { get; private set; }

    [Header("Word Setup")]
    public string targetWord = "FIRE";
    public string wordFormationSceneName = "WordFormationScene";

    [Header("UI")]
    public GameObject letterSlotPrefab;
    public Transform lettersContainer;

    [Header("Slot Colors")]
    public Color emptySlotColor = new Color(0.25f, 0.25f, 0.25f, 1f);
    public Color filledSlotColor = Color.white;
    public Color filledTextColor = Color.black;

    private List<char> collectedLetters = new List<char>();
    private List<GameObject> slotObjects = new List<GameObject>();

    void Awake()
    {
        // Ensure only one instance exists
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    void Start()
    {
        CreateEmptySlots();
    }

    
    private void CreateEmptySlots()
    {
        // Clear old slots
        foreach (Transform child in lettersContainer)
        {
            Destroy(child.gameObject);
        }

        slotObjects.Clear();

        // Create slots based on word length
        for (int i = 0; i < targetWord.Length; i++)
        {
            GameObject slot = Instantiate(letterSlotPrefab, lettersContainer);
            slot.name = "LetterSlot_" + i;

            Image bg = slot.GetComponent<Image>();
            TMP_Text text = slot.GetComponentInChildren<TMP_Text>();

            if (bg != null)
                bg.color = emptySlotColor;

            if (text != null)
                text.text = "";

            slotObjects.Add(slot);
        }
    }

    
    public void AddLetter(char letter, int checkpointIndex = 0)
    {
        letter = char.ToUpper(letter);

        if (collectedLetters.Count >= targetWord.Length)
            return;

        collectedLetters.Add(letter);

        FillNextSlot(letter);

        // If word complete → go to next scene
        if (collectedLetters.Count >= targetWord.Length)
        {
            string word = new string(collectedLetters.ToArray());
            Debug.Log("Word collected: " + word);

            if (!string.IsNullOrEmpty(wordFormationSceneName))
            {
                SceneManager.LoadScene(wordFormationSceneName);
            }
        }
    }

    
    private void FillNextSlot(char letter)
    {
        for (int i = 0; i < slotObjects.Count; i++)
        {
            GameObject slot = slotObjects[i];

            TMP_Text text = slot.GetComponentInChildren<TMP_Text>();
            Image bg = slot.GetComponent<Image>();

            if (text != null && string.IsNullOrEmpty(text.text))
            {
                text.text = letter.ToString();

                if (bg != null)
                    bg.color = filledSlotColor;

                text.color = filledTextColor;
                return;
            }
        }
    }

    // Optional reset
    public void ResetInventory()
    {
        collectedLetters.Clear();
        CreateEmptySlots();
    }
}